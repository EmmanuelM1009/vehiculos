<?php
session_start();

$servername = "localhost";
$username = "id21364599_ejercicios";
$password = "Mayodia03.";
$dbname = "id21364599_ejercicios";

require_once '../vendor/autoload.php';

use Picqer\Barcode\BarcodeGeneratorPNG;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === 0) {
        $imagen = $_FILES['imagen'];

        
        $nombreArchivo = $imagen['name'];
        $extension = pathinfo($nombreArchivo, PATHINFO_EXTENSION);

      
        $nombreUnico = uniqid('imagen_') . '.' . $extension;

       
        $rutaDestinoImagen = '../imagenes/' . $nombreUnico;

       
        if (move_uploaded_file($imagen['tmp_name'], $rutaDestinoImagen)) {
            
        } else {
            
        }
    } else {
        
        $nombreUnico = 'imagen_predeterminada.jpg';
    }

    
    $marca = $_POST['marca'];
    $tipo = $_POST['tipo'];
    $clasificacion = $_POST['clasificacion'];

    
    $codigoBarras = uniqid(); // Genera un código de barras único 

    // Genera el código de barras en formato PNG
    $barcodeGenerator = new BarcodeGeneratorPNG();
    $barcodeImage = $barcodeGenerator->getBarcode($codigoBarras, $barcodeGenerator::TYPE_CODE_128);

    // Guardar el código de barras en la carpeta "codebar"
    $nombreArchivoCodigoBarra = 'codebar_' . $codigoBarras . '.png';
    $rutaDestinoCodigoBarra = '../codebar/' . $nombreArchivoCodigoBarra;

    

    
    $conexion = new mysqli($servername, $username, $password, $dbname);

    if ($conexion->connect_error) {
        die('Error de conexión: ' . $conexion->connect_error);
    }


    $sql = "INSERT INTO repuestos (marca, tipo, clasificacion, codigo_barras, imagen) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);

    if ($stmt) {
        
        $stmt->bind_param('sssss', $marca, $tipo, $clasificacion, $nombreArchivoCodigoBarra, $nombreUnico);
        $stmt->execute();

       
        if ($stmt->affected_rows > 0) {
            $_SESSION['mensaje'] = 'Registro de repuesto exitoso';
        } else {
            $_SESSION['mensaje'] = 'Error al insertar el repuesto en la base de datos';
        }

       
        $stmt->close();
    } else {
        $_SESSION['mensaje'] = 'Error en la consulta SQL: ' . $conexion->error;
    }

    
    $conexion->close();
} else {
   
    $_SESSION['mensaje'] = 'Error al acceder a la página de guardado de repuesto';
}


header('Location: ../form/formulario_registro_repuesto.php');
exit();
?>